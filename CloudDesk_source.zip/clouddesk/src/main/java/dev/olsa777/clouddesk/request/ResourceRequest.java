package dev.olsa777.clouddesk.request;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "resource_requests")
public class ResourceRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String title;
    @Column(nullable = false, length = 2000)
    private String description;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Environment environment;
    @Column(nullable = false)
    private int cpu;
    @Column(nullable = false)
    private int memoryGb;
    @Column(nullable = false)
    private int storageGb;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RequestStatus status;
    @Column(nullable = false, updatable = false)
    private Instant createdAt;
    @Column(nullable = false)
    private Instant updatedAt;
    // If two operators update the same row concurrently, one receives HTTP 409.
    @Version
    private long version;

    protected ResourceRequest() { }

    public ResourceRequest(CreateRequest input) {
        title = input.title().trim();
        description = input.description().trim();
        environment = input.environment();
        cpu = input.cpu();
        memoryGb = input.memoryGb();
        storageGb = input.storageGb();
        status = RequestStatus.NEW;
        createdAt = Instant.now();
        updatedAt = createdAt;
    }

    public void transitionTo(RequestStatus next) {
        if (!status.canTransitionTo(next)) {
            throw new InvalidTransitionException("Переход " + status + " → " + next + " запрещён");
        }
        status = next;
        updatedAt = Instant.now();
    }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Environment getEnvironment() { return environment; }
    public int getCpu() { return cpu; }
    public int getMemoryGb() { return memoryGb; }
    public int getStorageGb() { return storageGb; }
    public RequestStatus getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
